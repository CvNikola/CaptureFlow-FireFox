const De = globalThis.browser;
De?.runtime?.getURL("").startsWith("moz-extension://") && (globalThis.chrome = De);
function V() {
  return typeof chrome < "u" && !!chrome.runtime?.getURL?.("").startsWith("moz-extension://");
}
const se = "captureflow.popup-window.v1";
async function Le() {
  return (await chrome.storage.session.get(se))[se];
}
async function mt(e) {
  if (e.id !== chrome.runtime.id || e.url?.split("?")[0] !== chrome.runtime.getURL("popup.html"))
    throw new Error("Untrusted window request.");
  const t = await Le();
  if (t)
    try {
      const n = await chrome.windows.get(t.windowId, { populate: !0 });
      if (n.type === "popup" && n.tabs?.some((i) => i.url === chrome.runtime.getURL("popup.html?detached=1"))) {
        await chrome.windows.update(t.windowId, { focused: !0 });
        return;
      }
    } catch {
    }
  const [o] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  if (o?.windowId === void 0)
    throw new Error("Open CaptureFlow from a browser window first.");
  const r = await chrome.windows.create({
    url: chrome.runtime.getURL("popup.html?detached=1"),
    type: "popup",
    width: 420,
    height: 640,
    focused: !0
  });
  if (r?.id === void 0)
    throw new Error("The browser could not create the CaptureFlow window.");
  await chrome.storage.session.set({
    [se]: { windowId: r.id, sourceWindowId: o.windowId }
  });
}
async function gt(e) {
  if (e < 0) return;
  const t = await Le();
  if (!t || t.windowId === e) return;
  (await chrome.windows.get(e)).type === "normal" && await chrome.storage.session.set({ [se]: { ...t, sourceWindowId: e } });
}
async function $e(e) {
  if (new URL(e.url ?? chrome.runtime.getURL("popup.html")).searchParams.get("detached") !== "1")
    return (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0];
  const t = await Le();
  if (!t || e.tab?.windowId !== t.windowId)
    throw new Error("Reopen the CaptureFlow window from the browser toolbar.");
  let o;
  try {
    o = (await chrome.tabs.query({ active: !0, windowId: t.sourceWindowId }))[0];
  } catch {
  }
  if (!o) {
    const r = await chrome.windows.getAll({ windowTypes: ["normal"] }), n = r.find((i) => i.focused) ?? r[0];
    n?.id !== void 0 && (o = (await chrome.tabs.query({ active: !0, windowId: n.id }))[0]);
  }
  if (!o) throw new Error("Open a webpage in a browser window first.");
  return await chrome.windows.update(o.windowId, { focused: !0 }), o;
}
const yt = "captureflow.window", bt = "https://captureflow-billing.captureflow-billing.workers.dev", Et = { kty: "EC", x: "ZnqEBzEbbg6uxm5fcmq6TzxLEOlOSzjTVnDQBBTx4Jk", y: "SLMq1o-4V4V9a3FordCrX5ExsjnwwP04ZJVBIt5wSgU", crv: "P-256" }, vt = {
  apiOrigin: bt,
  publicKey: Et
}, g = vt;
function le() {
  return /^https:\/\/[a-z0-9.-]+$/.test(g.apiOrigin) && g.publicKey?.kty === "EC";
}
const Ze = [
  "authenticationInfo",
  "personallyIdentifyingInfo",
  "financialAndPaymentInfo"
];
function St() {
  return { origins: [g.apiOrigin + "/*"], data_collection: Ze };
}
async function et() {
  return !V() || chrome.permissions.contains(St());
}
const Tt = !0, At = {
  enabled: Tt
}, It = "captureflow.auth", te = "captureflow.auth.v1", ue = "captureflow.guest.v1";
function ae(e) {
  const t = e.trim();
  return t ? t.length > 254 || !/^[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+$/.test(t) ? "Enter a valid email address, for example name@example.com." : "" : "Enter your email address.";
}
function ne(e) {
  return e.length < 6 ? "Use at least 6 characters for your password." : e.length > 128 ? "Use no more than 128 characters for your password." : /[A-Z]/.test(e) ? /[0-9]/.test(e) ? /[^\p{L}\p{N}\s]/u.test(e) ? "" : "Include at least one special character, such as !, @ or #." : "Include at least one number." : "Include at least one uppercase letter.";
}
class tt extends Error {
  constructor(t, o) {
    super(o), this.status = t, this.name = "BillingHttpError";
  }
  status;
}
async function Ie(e, t, o) {
  if (!le())
    throw new Error("Automatic subscription activation is not configured yet.");
  if (V() && !await et())
    throw new Error("Allow account data access to use your account, or continue without login.");
  const r = await fetch(g.apiOrigin + e, {
    method: o ? "POST" : "GET",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + t },
    ...o ? { body: JSON.stringify(o) } : {},
    credentials: "omit",
    cache: "no-store",
    redirect: "error",
    referrerPolicy: "no-referrer",
    signal: AbortSignal.timeout(25e3)
  }), n = await r.json();
  if (!r.ok)
    throw new tt(
      r.status,
      n && typeof n == "object" && "error" in n && typeof n.error == "string" ? n.error.slice(0, 240) : "Subscription service is temporarily unavailable."
    );
  return n;
}
function ye() {
  return typeof chrome < "u" && !!chrome.runtime?.id;
}
const U = "captureflow.billing.v1";
let j = null, Z = { plan: "basic", paidUntil: 0 }, je = 0, Ke = 0;
const kt = /* @__PURE__ */ new Set(), be = (e) => Uint8Array.from(atob(e.replaceAll("-", "+").replaceAll("_", "/")), (t) => t.charCodeAt(0)), rt = (e) => btoa(String.fromCharCode(...e)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
async function Ct(e) {
  return rt(
    new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(e)))
  );
}
async function de(e, t, o, r, n = Date.now()) {
  if (e.length > 4096 || !/^[A-Za-z0-9_-]{43}$/.test(t))
    throw new Error("Invalid license data.");
  const i = e.split(".");
  if (i.length !== 3 || i.some((f) => !/^[A-Za-z0-9_-]+$/.test(f)))
    throw new Error("Invalid license signature.");
  const [a, c, l] = i, d = JSON.parse(new TextDecoder().decode(be(a)));
  if (d.alg !== "ES256" || d.typ !== "JWT")
    throw new Error("Unsupported license signature.");
  const s = await crypto.subtle.importKey(
    "jwk",
    r,
    { name: "ECDSA", namedCurve: "P-256" },
    !1,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" },
    s,
    be(l),
    new TextEncoder().encode(a + "." + c)
  ))
    throw new Error("License signature verification failed.");
  const u = JSON.parse(new TextDecoder().decode(be(c))), p = Math.floor(n / 1e3);
  if (u.iss !== o || u.aud !== "captureflow" || u.sub !== await Ct(t) || !["basic", "pro"].includes(u.plan) || !Number.isSafeInteger(u.iat) || !Number.isSafeInteger(u.exp) || !Number.isSafeInteger(u.paidUntil) || u.paidUntil < 0 || u.iat > p + 300 || u.exp <= p || u.exp <= u.iat || u.exp - u.iat > 21600 || (u.source === "admin" ? u.plan !== "pro" || u.paidUntil !== 0 || u.exp - u.iat > 600 : u.plan === "pro" && (u.paidUntil <= n || u.exp * 1e3 > u.paidUntil)))
    throw new Error("This license has expired or belongs to another installation.");
  return u;
}
function ot() {
  const e = je = Math.max(je, Date.now()), t = j?.plan === "pro" && j.exp * 1e3 > e && (j.source === "admin" || j.paidUntil > e) ? "pro" : "basic", o = j?.paidUntil ?? 0;
  if (Z.plan !== t || Z.paidUntil !== o) {
    Z = { plan: t, paidUntil: o };
    for (const r of kt) r();
  }
}
function nt() {
  return ot(), Z.plan;
}
function xt() {
  return Z;
}
async function pe() {
  if (!ye()) return null;
  if (!chrome.storage?.local) {
    const t = await chrome.runtime.sendMessage({
      channel: "captureflow.billing",
      type: "CACHED"
    });
    return t?.ok ? t.data : null;
  }
  const e = (await chrome.storage.local.get(U))[U];
  return !e || typeof e.recoveryKey != "string" || !/^[A-Za-z0-9_-]{43}$/.test(e.recoveryKey) ? null : {
    recoveryKey: e.recoveryKey,
    entitlement: typeof e.entitlement == "string" ? e.entitlement : "",
    checkedAt: typeof e.checkedAt == "number" ? e.checkedAt : 0,
    checkoutPending: e.checkoutPending === !0
  };
}
async function A() {
  if (!le()) return;
  const e = ++Ke;
  let t = null;
  try {
    const o = await pe();
    o?.entitlement && g.publicKey && (t = await de(
      o.entitlement,
      o.recoveryKey,
      g.apiOrigin,
      g.publicKey
    ));
  } catch {
  }
  Ke === e && (j = t, ot());
}
async function G(e) {
  await chrome.storage.local.remove(te), await chrome.storage.local.remove(U), await chrome.storage.local.set({ [ue]: e }), await A();
}
async function N(...e) {
  try {
    return await Ie(...e);
  } catch (t) {
    const o = e[2]?.operation;
    throw t instanceof tt && t.status === 401 && o !== "login" && o !== "register" && await G(!1), t;
  }
}
async function B() {
  const e = (await chrome.storage.local.get(te))[te];
  return !e || typeof e.idToken != "string" || typeof e.refreshToken != "string" || typeof e.uid != "string" || typeof e.email != "string" || typeof e.expiresAt != "number" ? null : e;
}
async function it(e) {
  if (!e.idToken || !e.refreshToken || !e.uid || !Number.isFinite(e.expiresAt) || ae(e.email))
    throw new Error("The account service returned an invalid session. Please log in again.");
  await chrome.storage.local.set({ [te]: e, [ue]: !1 });
}
async function J(e, t = !1) {
  if (!e.emailVerified) return;
  const o = await pe(), r = await N("/v1/account", e.idToken, {
    previousKey: o?.recoveryKey ?? ""
  });
  if (!g.publicKey) throw new Error("Subscription verification is not configured.");
  if (t) {
    o?.recoveryKey !== r.recoveryKey && await chrome.storage.local.set({
      [U]: {
        recoveryKey: r.recoveryKey,
        entitlement: "",
        checkedAt: 0
      }
    }), await A();
    return;
  }
  const n = await N("/v1/license", r.recoveryKey);
  if (!g.publicKey) throw new Error("Subscription verification is not configured.");
  await de(
    n.entitlement,
    r.recoveryKey,
    g.apiOrigin,
    g.publicKey
  ), await chrome.storage.local.set({
    [U]: {
      recoveryKey: r.recoveryKey,
      entitlement: n.entitlement,
      checkedAt: Date.now(),
      checkoutPending: o?.recoveryKey === r.recoveryKey && o.checkoutPending === !0
    }
  }), await A();
}
async function K(e = !1) {
  let t = await B();
  return t ? ((e || t.expiresAt < Date.now() + 6e4) && (t = await N("/v1/auth", "", {
    operation: "refresh",
    refreshToken: t.refreshToken
  }), await it(t)), t) : null;
}
async function Pt() {
  const e = await K(!0);
  if (!e) throw new Error("Log in to your CaptureFlow account before subscribing to Pro.");
  if (!e.emailVerified)
    throw new Error("Confirm your email first. Open Login to resend the verification email.");
  return await J(e, !0), e.idToken;
}
async function We(e, t) {
  const o = t.url?.split("?")[0];
  if (t.id !== chrome.runtime.id || !["popup.html"].some((a) => o === chrome.runtime.getURL(a)))
    throw new Error("Untrusted account request.");
  if (!e || typeof e != "object" || !("type" in e))
    throw new Error("Invalid account request.");
  const r = e;
  if (r.type === "STATUS" && V() && !await et() && await B() && await G(!1), r.type === "LOGOUT" || r.type === "GUEST")
    await G(r.type === "GUEST");
  else if (r.type !== "STATUS")
    if (["LOGIN", "REGISTER", "RESET"].includes(String(r.type))) {
      const a = typeof r.email == "string" ? r.email.trim() : "";
      if (ae(a)) throw new Error(ae(a));
      if (r.type === "REGISTER" && ne(typeof r.password == "string" ? r.password : ""))
        throw new Error(ne(typeof r.password == "string" ? r.password : ""));
      if (r.type !== "RESET" && (typeof r.password != "string" || !r.password || r.password.length > 128))
        throw new Error("Enter your password.");
      if (r.type === "RESET")
        await N("/v1/auth", "", { operation: "reset", email: a }), await G(!1);
      else {
        const c = await N(
          "/v1/auth",
          "",
          {
            operation: r.type === "LOGIN" ? "login" : "register",
            ...r.type === "REGISTER" ? { sendVerification: "true" } : {},
            email: a,
            password: r.password
          }
        ), l = await B();
        if (l && l.uid !== c.uid && (await chrome.storage.local.remove(U), await A()), r.type === "REGISTER") {
          if (await G(!1), c.verificationEmailSent !== !0)
            throw new Error(
              c.emailVerified ? "Your email is already verified. Log in to continue." : "Your account was created, but email sending was not confirmed. Log in and use Resend verification email."
            );
        } else
          await it(c), await J(c);
      }
    } else if (r.type === "RESET_FINISH") {
      if (typeof r.email != "string" || ae(r.email))
        throw new Error("Enter a valid email address.");
      if (typeof r.password != "string" || ne(r.password))
        throw new Error(ne(typeof r.password == "string" ? r.password : ""));
      await N("/v1/auth", "", {
        operation: "resetFinish",
        email: r.email.trim(),
        password: r.password,
        link: typeof r.link == "string" ? r.link : ""
      }), (await B())?.email.toLowerCase() === r.email.trim().toLowerCase() && (await chrome.storage.local.remove(te), await chrome.storage.local.remove(U), await A());
    } else if (r.type === "VERIFY_FINISH") {
      const a = await K();
      if (!a) throw new Error("Please log in again.");
      await N("/v1/auth", "", {
        operation: "verifyFinish",
        idToken: a.idToken,
        link: typeof r.link == "string" ? r.link : ""
      });
      const c = await K(!0);
      c && await J(c);
    } else if (r.type === "RESUME") {
      const a = await K(!0);
      a && await J(a);
    } else if (r.type === "VERIFY") {
      const a = await K();
      if (!a) throw new Error("Please log in again.");
      const c = await N("/v1/auth", "", { operation: "verify", idToken: a.idToken });
      if (c.alreadyVerified) {
        const l = await K(!0);
        l && await J(l);
      } else if (c.sent !== !0 || c.email?.trim().toLowerCase() !== a.email.trim().toLowerCase())
        throw new Error("The email service did not confirm sending. Please try again.");
    } else throw new Error("Unknown account command.");
  const n = await B(), i = (await chrome.storage.local.get(ue))[ue] === !0;
  return {
    configured: At.enabled,
    guest: i,
    user: n ? { email: n.email, emailVerified: n.emailVerified } : null
  };
}
const Lt = "captureflow.billing";
async function Ut(e, t) {
  if (t.id !== chrome.runtime.id || !t.url?.startsWith(chrome.runtime.getURL("")) || t.tab && !["popup.html", "capture.html", "history.html", "recording.html"].some(
    (l) => t.url.split("?")[0] === chrome.runtime.getURL(l)
  ))
    throw new Error("Untrusted billing request.");
  if (!e || typeof e != "object" || !("type" in e))
    throw new Error("Invalid billing command.");
  const o = e;
  let r = await pe();
  const i = (await B())?.emailVerified === !0, a = () => ({
    configured: le(),
    plan: nt(),
    paidUntil: xt().paidUntil,
    recoveryKey: i ? r?.recoveryKey ?? "" : "",
    checkedAt: r?.checkedAt ?? 0,
    checkoutPending: i && r?.checkoutPending === !0
  });
  if (await A(), o.type === "STATUS") return a();
  if (o.type === "CACHED") return r;
  if (o.type === "REFRESH" && !i) return a();
  if (!le() || !g.publicKey)
    throw new Error("Automatic subscription activation is not configured yet.");
  const c = async (l) => {
    await chrome.storage.local.set({ [U]: l }), r = l, await A();
  };
  if (o.type === "REFRESH" && r && r.checkedAt > Date.now() - 1e4)
    try {
      return await de(
        r.entitlement,
        r.recoveryKey,
        g.apiOrigin,
        g.publicKey
      ), a();
    } catch {
    }
  if (o.type === "REFRESH" || o.type === "RESTORE") {
    const l = o.type === "RESTORE" && typeof o.key == "string" ? o.key.trim().replace(/^CF-/, "") : r?.recoveryKey;
    if (!l || !/^[A-Za-z0-9_-]{43}$/.test(l))
      throw new Error("Enter a valid CaptureFlow recovery key.");
    const d = await Ie(
      "/v1/license",
      l
    ), s = await de(
      d.entitlement,
      l,
      g.apiOrigin,
      g.publicKey
    );
    return await c({
      recoveryKey: l,
      entitlement: d.entitlement,
      checkedAt: Date.now(),
      checkoutPending: s.plan !== "pro" && o.type === "REFRESH" && r?.checkoutPending === !0
    }), { ...a(), verificationPending: d.verificationPending === !0 };
  }
  if (o.type === "CHECKOUT") {
    const l = await Pt();
    if (r = await pe(), o.plan !== "monthly" && o.plan !== "yearly")
      throw new Error("Choose a monthly or yearly plan.");
    r || await c({
      recoveryKey: rt(crypto.getRandomValues(new Uint8Array(32))),
      entitlement: "",
      checkedAt: 0
    });
    const d = r.recoveryKey, s = await Ie("/v1/checkout", d, {
      plan: o.plan,
      ...l ? { idToken: l } : {}
    }), u = new URL(s.url);
    if (u.protocol !== "https:" || !["www.paypal.com", "www.sandbox.paypal.com"].includes(u.hostname) || u.username || u.password || u.port)
      throw new Error("Unexpected PayPal checkout address.");
    return await c({ ...r, checkoutPending: !0, checkedAt: 0 }), await chrome.tabs.create({ url: u.href }), a();
  }
  if (o.type === "FORGET")
    return await chrome.storage.local.remove(U), r = null, await A(), a();
  throw new Error("Unknown billing command.");
}
const Rt = "captureflow/history/v1";
function Ft(e) {
  const t = e && typeof e == "object" ? e : null, o = typeof t?.message == "string" ? t.message : "Local history is unavailable. Try again.";
  return t?.name === "QuotaExceededError" || /quota/i.test(o) ? "Local history storage is full. Download this capture, delete unneeded history or free disk space, then try Save to history again." : o;
}
const ke = {
  basic: {
    label: "Basic",
    screenshots: 100,
    videos: 10,
    maxVideoMs: 3e5,
    editor: !1,
    adjustableQuality: !1,
    imageWidth: 1920
  },
  pro: {
    label: "Pro",
    screenshots: 1 / 0,
    videos: 1 / 0,
    maxVideoMs: 1 / 0,
    editor: !0,
    adjustableQuality: !0,
    imageWidth: 1 / 0
  }
};
function at() {
  return nt();
}
function Nt(e, t = at()) {
  return ke[t].adjustableQuality ? { ...e } : { ...e, quality: "standard" };
}
const ee = "captureflow.usage.v1";
function Mt(e = /* @__PURE__ */ new Date()) {
  return e.toISOString().slice(0, 7);
}
function Ge(e, t = /* @__PURE__ */ new Date()) {
  const o = Mt(t), r = e && typeof e == "object" ? e : {}, n = typeof r.month == "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(r.month) ? r.month : "";
  if (n < o) return { month: o, screenshots: [], videos: [] };
  const i = (a) => Array.isArray(r[a]) ? [
    ...new Set(
      r[a].filter(
        (c) => typeof c == "string" && c.length > 0
      )
    )
  ] : [];
  return { month: n, screenshots: i("screenshots"), videos: i("videos") };
}
async function Ue(e = /* @__PURE__ */ new Date()) {
  try {
    if (ye())
      return Ge((await chrome.storage.local.get(ee))[ee], e);
    const t = localStorage.getItem(ee);
    return Ge(t ? JSON.parse(t) : null, e);
  } catch {
    throw new Error("Monthly usage could not be read. Reopen CaptureFlow and try again.");
  }
}
function Re(e, t, o, r = at()) {
  const n = t === "screenshot" ? e.screenshots : e.videos;
  if (o && n.includes(o)) return;
  const i = t === "screenshot" ? ke[r].screenshots : ke[r].videos;
  if (n.length >= i)
    throw new Error(
      "Basic monthly limit reached: " + i + (t === "screenshot" ? " screenshots" : " videos") + ". Limits reset on the first day of each month (UTC)."
    );
}
async function ct(e, t, o = /* @__PURE__ */ new Date()) {
  if (!t) throw new Error("Missing capture identifier.");
  const r = await Ue(o);
  Re(r, e, t);
  const n = e === "screenshot" ? r.screenshots : r.videos;
  if (n.includes(t)) return r;
  n.push(t);
  try {
    ye() ? await chrome.storage.local.set({ [ee]: r }) : localStorage.setItem(ee, JSON.stringify(r));
  } catch {
    throw new Error("Monthly usage could not be saved. Check available browser storage.");
  }
  return r;
}
async function Be(e, t = !0) {
  if (e.controlsWindowId != null)
    try {
      return await chrome.windows.update(
        e.controlsWindowId,
        t ? { focused: !0, state: "normal", width: 280, height: 106 } : { width: 280, height: 106 }
      ), e;
    } catch {
    }
  const o = await chrome.windows.create({
    url: chrome.runtime.getURL("controls.html?id=" + encodeURIComponent(e.id)),
    type: "popup",
    width: 280,
    height: 106,
    focused: t
  });
  if (o?.id === void 0)
    throw new Error(
      "Chrome could not open recording controls. Use the extension popup to control this recording."
    );
  return {
    ...e,
    controlsWindowId: o.id,
    controlsTabId: o.tabs?.[0]?.id ?? null,
    controlsOpened: !0,
    controlsError: ""
  };
}
async function Ee(e) {
  if (e.controlsWindowId != null)
    try {
      await chrome.windows.remove(e.controlsWindowId);
    } catch {
    }
}
const L = Object.freeze({
  schemaVersion: 1,
  theme: "dark",
  screenshotFormat: "png",
  jpegQuality: 90,
  filename: "CaptureFlow",
  recordingMode: "tab",
  recordingQuality: "high",
  microphone: !1,
  autoSave: !0
});
function ze(e) {
  const t = typeof e == "object" && e !== null ? e : {}, o = (n, i, a) => i.includes(n) ? n : a, r = typeof t.filename == "string" ? t.filename.trim().replace(/[<>:"/\\|?*\u0000-\u001f]/g, "").slice(0, 80) : "";
  return {
    schemaVersion: 1,
    theme: o(t.theme, ["dark", "light", "system"], L.theme),
    screenshotFormat: o(
      t.screenshotFormat,
      ["png", "jpeg"],
      L.screenshotFormat
    ),
    jpegQuality: typeof t.jpegQuality == "number" && Number.isFinite(t.jpegQuality) ? Math.max(10, Math.min(100, Math.round(t.jpegQuality))) : L.jpegQuality,
    filename: r || L.filename,
    recordingMode: o(
      t.recordingMode,
      ["tab", "window", "screen"],
      L.recordingMode
    ),
    recordingQuality: o(
      t.recordingQuality,
      ["standard", "high", "maximum"],
      L.recordingQuality
    ),
    // Retained for older stored records; voice capture is disabled.
    microphone: !1,
    autoSave: typeof t.autoSave == "boolean" ? t.autoSave : L.autoSave
  };
}
const ve = "captureflow.settings.v1";
async function _t() {
  if (ye()) {
    const t = await chrome.storage.local.get(ve);
    return ze(t[ve]);
  }
  const e = localStorage.getItem(ve);
  try {
    return ze(e ? JSON.parse(e) : L);
  } catch {
    return { ...L };
  }
}
const Ot = "captureflow.recordings.v1", Ht = 2;
function Dt() {
  return new Promise((e, t) => {
    let o = !1;
    const r = indexedDB.open(Ot, Ht);
    r.onupgradeneeded = () => {
      const n = r.result;
      n.objectStoreNames.contains("recordings") || n.createObjectStore("recordings", { keyPath: "id" }), n.objectStoreNames.contains("chunks") || n.createObjectStore("chunks", { keyPath: ["id", "index"] }).createIndex("recording", "id"), n.objectStoreNames.contains("screenshots") || n.createObjectStore("screenshots", { keyPath: "id" }), n.objectStoreNames.contains("assets") || n.createObjectStore("assets", { keyPath: ["id", "kind"] }).createIndex("capture", "id");
    }, r.onerror = () => t(r.error ?? new Error("Local capture storage is unavailable.")), r.onblocked = () => {
      o = !0, t(new Error("Close other CaptureFlow pages and retry the history upgrade."));
    }, r.onsuccess = () => {
      const n = r.result;
      if (o) {
        n.close();
        return;
      }
      n.onversionchange = () => n.close(), e(n);
    };
  });
}
async function I(e, t, o) {
  const r = await Dt();
  try {
    return await new Promise((n, i) => {
      const a = r.transaction(e, t);
      let c, l = null;
      a.oncomplete = () => n(c), a.onabort = () => i(l ?? a.error ?? new Error("Local capture storage transaction failed.")), a.onerror = () => {
      };
      const d = (s) => {
        l = s, a.abort();
      };
      try {
        o(
          a,
          (s) => {
            c = s;
          },
          d
        );
      } catch (s) {
        l = s instanceof Error ? s : new Error("Local history operation failed."), a.abort();
      }
    });
  } finally {
    r.close();
  }
}
function he(e, t) {
  const o = e.objectStore("assets").index("capture").openKeyCursor(IDBKeyRange.only(t));
  o.onsuccess = () => {
    const r = o.result;
    r && (e.objectStore("assets").delete(r.primaryKey), r.continue());
  };
}
function Fe(e, t) {
  const o = e.objectStore("chunks").index("recording").openKeyCursor(IDBKeyRange.only(t));
  o.onsuccess = () => {
    const r = o.result;
    r && (e.objectStore("chunks").delete(r.primaryKey), r.continue());
  };
}
async function jt(e) {
  await I(["recordings"], "readwrite", (t) => {
    t.objectStore("recordings").put(e);
  });
}
async function we(e) {
  return I(["recordings"], "readonly", (t, o) => {
    const r = t.objectStore("recordings").get(e);
    r.onsuccess = () => o(r.result ?? null);
  });
}
async function Kt() {
  return I(["recordings"], "readonly", (e, t) => {
    const o = e.objectStore("recordings").getAll();
    o.onsuccess = () => t(o.result.sort((r, n) => n.createdAt - r.createdAt));
  });
}
async function Wt(e, t) {
  return I(["chunks"], "readonly", (o, r) => {
    const n = o.objectStore("chunks").index("recording").getAll(IDBKeyRange.only(e));
    n.onsuccess = () => {
      const i = n.result;
      if (i.sort((a, c) => a.index - c.index), !i.length) {
        r(new Blob([], { type: t }));
        return;
      }
      r(
        new Blob(
          i.map((a) => a.blob),
          { type: t }
        )
      );
    };
  });
}
async function Gt(e) {
  return I(["recordings"], "readwrite", (t, o, r) => {
    const n = t.objectStore("recordings"), i = n.get(e);
    i.onsuccess = () => {
      const a = i.result;
      if (!a) {
        r(new Error("This temporary recording has already been removed."));
        return;
      }
      const c = { ...a, retention: "saved" };
      n.put(c), o(c);
    };
  });
}
async function Bt(e, t) {
  await I(["recordings"], "readwrite", (o) => {
    const r = o.objectStore("recordings"), n = r.get(e);
    n.onsuccess = () => {
      const i = n.result;
      i?.retention === "temporary" && r.put({ ...i, previewTabId: t });
    };
  });
}
async function zt(e) {
  return I(["recordings", "chunks", "assets"], "readwrite", (t, o) => {
    let r = 0;
    const n = t.objectStore("recordings").openCursor();
    n.onsuccess = () => {
      const i = n.result;
      if (!i) {
        o(r);
        return;
      }
      const a = i.value;
      a.retention === "temporary" && !e.has(a.id) && (i.delete(), Fe(t, a.id), he(t, a.id), r++), i.continue();
    };
  });
}
const Ve = "captureflow.history.changed";
function ce() {
  typeof window < "u" && window.dispatchEvent(new Event(Ve));
  try {
    if (typeof BroadcastChannel == "function") {
      const e = new BroadcastChannel(Ve);
      e.postMessage("changed"), e.close();
    }
  } catch {
  }
}
const Vt = "captureflow/recording/v1", Yt = "captureflow/recording-host/v1", Ce = "captureflow.recording.v1", k = (e) => !!e && ["setup", "starting", "recording", "paused", "stopping"].includes(e.status);
function qt(e, t = Date.now()) {
  return Math.max(
    0,
    e.elapsedMs + (e.clockStartedAt === null ? 0 : Math.max(0, t - e.clockStartedAt))
  );
}
function Qt(e) {
  if (!e || typeof e != "object") throw new Error("Invalid recording options.");
  const t = e;
  if (!["tab", "window", "screen"].includes(String(t.mode)) || !["standard", "high", "maximum"].includes(String(t.quality)) || typeof t.microphone != "boolean" || typeof t.audio != "boolean")
    throw new Error("Invalid recording options.");
  return {
    mode: t.mode,
    quality: t.quality,
    microphone: !1,
    audio: t.audio
  };
}
const Ye = 32760, Xt = 64e6;
function Ne(e, t) {
  if (![e, t].every(Number.isSafeInteger) || e < 1 || t < 1)
    throw new Error("The screenshot has invalid dimensions.");
  if (e > Ye || t > Ye || e * t > Xt)
    throw new Error(
      "This page exceeds the safe screenshot size (32,760 pixels per side or 64 megapixels). Try a selected area or reduce browser zoom."
    );
}
function st(e) {
  let t;
  try {
    t = new URL(e);
  } catch {
    throw new Error("Open a normal website before capturing.");
  }
  if (!["http:", "https:"].includes(t.protocol) || t.hostname === "chromewebstore.google.com" || V() && ["addons.mozilla.org", "accounts.firefox.com", "support.mozilla.org"].includes(
    t.hostname
  ) || t.hostname === "chrome.google.com" && t.pathname.startsWith("/webstore"))
    throw new Error(
      (V() ? "Firefox" : "Chrome") + " protects this page. Open an ordinary HTTP or HTTPS webpage to capture it."
    );
  if (t.hostname === "chromewebstore.google.com")
    throw new Error("Chrome Web Store pages cannot be captured by CaptureFlow.");
}
function Me(e) {
  if (!e || ![
    e.width,
    e.height,
    e.documentWidth,
    e.documentHeight,
    e.scrollX,
    e.scrollY,
    e.dpr,
    e.visualScale
  ].every(Number.isFinite) || e.width <= 0 || e.height <= 0 || e.dpr <= 0)
    throw new Error("The page returned invalid viewport dimensions.");
  if (Math.abs(e.visualScale - 1) > 0.01)
    throw new Error("Reset pinch zoom before capturing this page. Browser zoom is supported.");
}
function lt(e, t, o, r) {
  if (Me(t), !e || ![e.x, e.y, e.width, e.height].every(Number.isFinite) || e.width < 2 || e.height < 2 || e.x < 0 || e.y < 0 || e.x + e.width > t.width + 0.5 || e.y + e.height > t.height + 0.5)
    throw new Error("Select a valid area at least 2 × 2 pixels inside the viewport.");
  const n = o / t.width, i = r / t.height, a = Math.max(0, Math.round(e.x * n)), c = Math.max(0, Math.round(e.y * i)), l = Math.min(o, Math.round((e.x + e.width) * n)), d = Math.min(r, Math.round((e.y + e.height) * i)), s = { x: a, y: c, width: l - a, height: d - c };
  return Ne(s.width, s.height), s;
}
function qe(e, t) {
  return Math.abs(e.width - t.width) < 0.5 && Math.abs(e.height - t.height) < 0.5 && Math.abs(e.dpr - t.dpr) < 1e-3 && Math.abs(e.scrollX - t.scrollX) < 1 && Math.abs(e.scrollY - t.scrollY) < 1;
}
async function Jt(e, t = !1) {
  const o = window;
  if (t) {
    o.__captureFlowFullSnapshot?.id === e && o.__captureFlowFullSnapshot.cleanup();
    return;
  }
  if (Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight ?? 0) <= innerHeight + 2 && Array.from(document.querySelectorAll("body *")).some((s) => {
    const u = s.getBoundingClientRect();
    return /auto|scroll/.test(getComputedStyle(s).overflowY) && s.scrollHeight > s.clientHeight + 50 && u.width * u.height > innerWidth * innerHeight * 0.5;
  }))
    throw new Error(
      "Nested scrolling pages are not supported. Use a visible or selected-area capture."
    );
  if (o.__captureFlowFullSnapshot)
    throw new Error("A full-page snapshot is already preparing this page.");
  const r = Array.from(document.images).filter((s) => s.loading === "lazy"), n = r.map((s) => ({ image: s, value: s.getAttribute("loading") })), i = document.createElement("style");
  i.textContent = "*,*::before,*::after{animation-play-state:paused!important;transition:none!important;overflow-anchor:none!important;}", document.documentElement.append(i);
  const a = Array.from(document.querySelectorAll("body *")).filter((s) => getComputedStyle(s).contentVisibility === "auto").map((s) => ({
    element: s,
    value: s.style.getPropertyValue("content-visibility"),
    priority: s.style.getPropertyPriority("content-visibility")
  }));
  for (const { element: s } of a)
    s.style.setProperty("content-visibility", "visible", "important");
  let c;
  const l = () => {
    clearTimeout(c), i.remove();
    for (const { element: s, value: u, priority: p } of a)
      u ? s.style.setProperty("content-visibility", u, p) : s.style.removeProperty("content-visibility");
    for (const { image: s, value: u } of n)
      u === null ? s.removeAttribute("loading") : s.setAttribute("loading", u);
    o.__captureFlowFullSnapshot?.id === e && delete o.__captureFlowFullSnapshot;
  };
  o.__captureFlowFullSnapshot = { id: e, cleanup: l }, c = setTimeout(l, 3e4);
  for (const s of r) s.loading = "eager";
  let d;
  try {
    await Promise.race([
      Promise.all(
        Array.from(document.images).map(
          (s) => s.complete ? Promise.resolve() : s.decode().catch(() => {
          })
        )
      ),
      new Promise((s) => {
        d = setTimeout(s, 1500);
      })
    ]);
  } finally {
    clearTimeout(d);
  }
}
async function _e(e, t) {
  try {
    const o = globalThis.browser ?? globalThis.chrome, r = window, n = () => new Promise((d, s) => {
      const u = setTimeout(
        () => s(
          new Error(
            "The source page stopped rendering. Keep its tab and window visible, then retry."
          )
        ),
        1e3
      );
      requestAnimationFrame(
        () => requestAnimationFrame(() => {
          clearTimeout(u), d();
        })
      );
    }), i = () => {
      if (!["text/html", "application/xhtml+xml"].includes(document.contentType))
        throw new Error("This document type is not supported. Open an HTML webpage.");
      const d = document.documentElement, s = document.body;
      return {
        width: innerWidth,
        height: innerHeight,
        documentWidth: Math.max(d.scrollWidth, s?.scrollWidth ?? 0),
        documentHeight: Math.max(d.scrollHeight, s?.scrollHeight ?? 0, innerHeight),
        scrollX,
        scrollY,
        dpr: devicePixelRatio,
        visualScale: visualViewport?.scale ?? 1
      };
    }, a = async () => {
      await n();
      const d = Array.from(document.images).filter((u) => {
        const p = u.getBoundingClientRect();
        return p.bottom > 0 && p.top < innerHeight && !u.complete;
      });
      let s;
      try {
        await Promise.race([
          Promise.all(d.map((u) => u.decode().catch(() => {
          }))),
          new Promise((u) => {
            s = setTimeout(u, 1e3);
          })
        ]);
      } finally {
        clearTimeout(s);
      }
      await n();
    };
    if (e.action === "restore")
      return r.__captureFlowPage?.id === t && r.__captureFlowPage.cleanup(), r.__captureFlowSelection?.id === t && r.__captureFlowSelection.cleanup(), await n(), { ok: !0, value: i() };
    if (e.action === "inspect") return { ok: !0, value: i() };
    if (e.action === "prepare") {
      if (r.__captureFlowPage) throw new Error("A capture is already preparing this page.");
      const d = i();
      if (d.documentWidth > d.width + 2)
        throw new Error(
          "Full-page capture currently supports vertical pages. Use a selected area for horizontally scrolling pages."
        );
      if (d.documentHeight <= d.height + 2 && Array.from(document.querySelectorAll("body *")).some((P) => {
        const oe = P.getBoundingClientRect(), ft = getComputedStyle(P);
        return /auto|scroll/.test(ft.overflowY) && P.scrollHeight > P.clientHeight + 50 && oe.width * oe.height > innerWidth * innerHeight * 0.5;
      }))
        throw new Error(
          "This page scrolls inside a container. Use Visible area or Selected area."
        );
      const s = new CSSStyleSheet();
      s.replaceSync(
        "html,body,*{scroll-behavior:auto!important;scroll-snap-type:none!important;overflow-anchor:none!important;animation-play-state:paused!important;transition:none!important;caret-color:transparent!important}*::-webkit-scrollbar{display:none!important}"
      ), document.adoptedStyleSheets = [...document.adoptedStyleSheets, s];
      const u = document.createElement("div");
      u.style.cssText = "position:fixed!important;right:20px!important;bottom:20px!important;z-index:2147483647!important;display:block!important;";
      const p = u.attachShadow({ mode: "closed" }), f = new CSSStyleSheet();
      f.replaceSync(
        ":host{all:initial}div{font:13px Segoe UI,sans-serif;background:#191c22;color:#eff1f5;border:1px solid #b6a2ff;border-radius:12px;padding:14px;box-shadow:0 8px 30px #0005}button{background:#b6a2ff;border:0;border-radius:6px;padding:6px 10px;margin-left:12px;cursor:pointer;color:#191c22}"
      ), p.adoptedStyleSheets = [f];
      const v = document.createElement("span");
      v.textContent = "CaptureFlow · preparing…";
      const m = document.createElement("div"), T = document.createElement("button");
      T.textContent = "Cancel", m.append(v, T), p.append(m), document.documentElement.append(u);
      const C = /* @__PURE__ */ new Map(), S = Array.from(document.querySelectorAll("video")).filter(
        (w) => !w.paused
      );
      S.forEach((w) => w.pause());
      let F;
      const O = (w) => {
        h(), o.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "PAGE_CANCEL",
          id: t,
          ...w ? { error: w } : {}
        }).catch(() => {
        });
      }, x = (w) => w.preventDefault(), H = (w) => {
        w.key === "Escape" ? (w.preventDefault(), O()) : ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(w.key) && w.preventDefault();
      }, h = () => {
        clearTimeout(F), u.remove(), document.adoptedStyleSheets = document.adoptedStyleSheets.filter((w) => w !== s), C.forEach((w, P) => {
          w.value ? P.style.setProperty("visibility", w.value, w.priority) : P.style.removeProperty("visibility");
        }), window.removeEventListener("wheel", x, !0), window.removeEventListener("touchmove", x, !0), window.removeEventListener("keydown", H, !0), window.scrollTo({ left: d.scrollX, top: d.scrollY, behavior: "instant" }), S.forEach((w) => {
          w.play().catch(() => {
          });
        }), r.__captureFlowPage?.id === t && delete r.__captureFlowPage;
      }, y = () => {
        clearTimeout(F), F = setTimeout(
          () => O("Capture stopped responding. The original page has been restored."),
          2e4
        );
      };
      r.__captureFlowPage = { id: t, cleanup: h, touch: y, hidden: C, hud: u, label: v, anchors: [] }, T.addEventListener("click", () => O()), window.addEventListener("wheel", x, { capture: !0, passive: !1 }), window.addEventListener("touchmove", x, { capture: !0, passive: !1 }), window.addEventListener("keydown", H, !0), y(), window.scrollTo({ left: 0, top: 0, behavior: "instant" });
      try {
        return await a(), await n(), { ok: !0, value: i() };
      } catch (w) {
        throw h(), w;
      }
    }
    if (e.action === "hideHud" || e.action === "showHud") {
      const d = r.__captureFlowPage;
      if (d?.id === t) {
        if (d.touch(), e.action === "showHud") {
          const s = /* @__PURE__ */ new Set();
          if (typeof document.elementsFromPoint == "function")
            for (const u of [innerWidth * 0.2, innerWidth * 0.5, innerWidth * 0.8])
              for (const p of [innerHeight * 0.25, innerHeight * 0.55, innerHeight * 0.85]) {
                const f = document.elementsFromPoint(u, p).find(
                  (m) => m !== d.hud && m !== document.documentElement && m !== document.body
                );
                if (!f) continue;
                let v = !1;
                for (let m = f; m; m = m.parentElement)
                  if (["fixed", "sticky"].includes(getComputedStyle(m).position)) {
                    v = !0;
                    break;
                  }
                v || s.add(f);
              }
          d.anchors = [...s].map((u) => {
            const p = u.getBoundingClientRect();
            return { element: u, top: p.top + scrollY, height: p.height };
          });
        }
        d.hud.style.setProperty(
          "display",
          e.action === "hideHud" ? "none" : "block",
          "important"
        ), e.action === "hideHud" && await n();
      }
      return { ok: !0, value: i() };
    }
    if (e.action !== "step") throw new Error("Unsupported page action.");
    const c = r.__captureFlowPage;
    if (!c || c.id !== t)
      throw new Error("The page capture expired. Please try again.");
    const l = () => {
      for (const d of c.anchors) {
        const s = d.element.getBoundingClientRect();
        if (!d.element.isConnected || Math.abs(s.top + scrollY - d.top) > 1 || Math.abs(s.height - d.height) > 1)
          throw new Error(
            "Content already captured shifted while loading. Wait for the page to stabilize, then retry."
          );
      }
    };
    return l(), c.touch(), c.label.textContent = "CaptureFlow · " + Math.round(e.progress) + "%", c.hud.style.setProperty("display", "block", "important"), e.hideSticky && Array.from(document.querySelectorAll("body *")).forEach((d) => {
      const s = getComputedStyle(d).position;
      (s === "fixed" || s === "sticky") && !c.hidden.has(d) && (c.hidden.set(d, {
        value: d.style.getPropertyValue("visibility"),
        priority: d.style.getPropertyPriority("visibility")
      }), d.style.setProperty("visibility", "hidden", "important"));
    }), window.scrollTo({ left: 0, top: e.y, behavior: "instant" }), await a(), l(), await n(), { ok: !0, value: i() };
  } catch (o) {
    return {
      ok: !1,
      error: o instanceof Error ? o.message : "The page could not be prepared."
    };
  }
}
function $t(e) {
  if (!e.startsWith("data:image/png;base64,"))
    throw new Error("Firefox returned an invalid screenshot.");
  const t = Uint8Array.from(atob(e.slice(22, 66)), (i) => i.charCodeAt(0));
  if (t.length < 24 || ![137, 80, 78, 71, 13, 10, 26, 10].every((i, a) => t[a] === i))
    throw new Error("Firefox returned an invalid PNG.");
  const o = new DataView(t.buffer), r = o.getUint32(16), n = o.getUint32(20);
  return Ne(r, n), { width: r, height: n };
}
async function Zt(e) {
  const t = { tabId: e.sourceTabId, documentIds: [e.documentId] }, o = async () => {
    const n = await chrome.tabs.get(e.sourceTabId);
    if (!n.active || n.windowId !== e.windowId || n.url !== e.sourceUrl)
      throw new Error("Keep the source webpage selected until capture finishes.");
    const a = (await chrome.scripting.executeScript({
      target: t,
      func: _e,
      args: [{ action: "inspect" }, e.id]
    }))[0]?.result;
    if (!a?.ok)
      throw new Error(a && !a.ok ? a.error : "The source document changed.");
    return a.value;
  }, r = (n = !1) => chrome.scripting.executeScript({
    target: t,
    func: Jt,
    args: [e.id, n]
  });
  try {
    await r();
    const n = await o(), i = Math.ceil(n.documentWidth * n.dpr), a = Math.ceil(n.documentHeight * n.dpr);
    if (Ne(i, a), n.documentWidth > n.width + 2)
      throw new Error("Horizontal scrolling pages are not supported. Use a selected-area capture.");
    const c = Math.max(1, Math.floor(Math.min(n.height, 2048 / n.dpr)));
    if (Math.ceil(n.documentHeight / c) > 120)
      throw new Error("This page needs too many screenshot sections.");
    const l = [];
    let d = 0;
    const s = Date.now();
    for (let p = 0; p < n.documentHeight; p += c) {
      if (Date.now() - s > 2e4)
        throw new Error("Full-page capture timed out. Try a smaller page.");
      const f = await o();
      if (f.documentWidth !== n.documentWidth || f.documentHeight !== n.documentHeight || f.dpr !== n.dpr)
        throw new Error("The page changed size during capture. Please retry.");
      const v = Math.min(c, n.documentHeight - p), m = {
        format: "png",
        rect: { x: 0, y: p, width: n.documentWidth, height: v },
        scale: n.dpr
      }, T = await chrome.tabs.captureVisibleTab(
        e.windowId,
        m
      );
      await o();
      const C = $t(T), S = Math.round(p * n.dpr), F = Math.round((p + v) * n.dpr);
      if (C.width !== i || Math.abs(C.height - (F - S)) > 1)
        throw new Error("Firefox returned an incomplete screenshot section.");
      if (d += T.length, d > 48 * 1024 * 1024)
        throw new Error("This screenshot exceeds the safe image memory limit.");
      l.push({ dataUrl: T, y: S, width: i, height: F - S });
    }
    const u = await o();
    return { tiles: l, width: i, height: Math.round(n.documentHeight * n.dpr), viewport: u };
  } finally {
    await r(!0).catch(() => {
    });
  }
}
const fe = "captureflow.capture.v1", er = "captureflow/capture/v1", E = (e) => !!e && ["starting", "selecting", "capturing"].includes(e.status);
function tr(e) {
  try {
    const t = globalThis.browser ?? globalThis.chrome, o = window;
    o.__captureFlowSelection?.cleanup();
    const r = document.activeElement instanceof HTMLElement ? document.activeElement : null, n = document.createElement("div");
    n.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;";
    const i = n.attachShadow({ mode: "closed" }), a = new CSSStyleSheet();
    a.replaceSync(
      ":host{all:initial}.overlay{position:fixed;inset:0;background:#0008;cursor:crosshair;touch-action:none;user-select:none;font:13px Segoe UI,sans-serif}.selection{position:absolute;display:none;border:2px solid #b6a2ff;box-sizing:border-box;box-shadow:0 0 0 99999px #0008;pointer-events:none}.dimensions{position:absolute;left:0;top:4px;padding:4px 7px;background:#191c22;color:white;white-space:nowrap;border-radius:4px;pointer-events:none}"
    ), i.adoptedStyleSheets = [a];
    const c = document.createElement("div");
    c.className = "overlay", c.tabIndex = 0, c.setAttribute("role", "dialog"), c.setAttribute(
      "aria-label",
      "Drag to capture an area. Release to capture. Escape to cancel."
    );
    const l = document.createElement("div");
    l.className = "selection";
    const d = document.createElement("div");
    d.className = "dimensions", l.append(d), c.append(l), i.append(c), document.documentElement.append(n);
    const s = {
      width: innerWidth,
      height: innerHeight,
      scrollX,
      scrollY,
      dpr: devicePixelRatio
    };
    let u = null, p = { x: 0, y: 0, width: 0, height: 0 }, f = !1, v;
    const m = (h) => h.preventDefault(), T = () => {
      clearTimeout(v), n.remove(), window.removeEventListener("keydown", O, !0), window.removeEventListener("resize", S), window.removeEventListener("scroll", S, !0), window.removeEventListener("wheel", m, !0), window.removeEventListener("touchmove", m, !0), o.__captureFlowSelection?.id === e && delete o.__captureFlowSelection, r?.focus({ preventScroll: !0 });
    }, C = (h) => {
      f || (f = !0, T(), t.runtime.sendMessage({
        channel: "captureflow/capture/v1",
        type: "PAGE_CANCEL",
        id: e,
        ...h ? { error: h } : {}
      }).catch(() => {
      }));
    }, S = () => C("The viewport changed during selection. Please select the area again."), F = async () => {
      if (f || p.width < 2 || p.height < 2) return;
      if (innerWidth !== s.width || innerHeight !== s.height || scrollX !== s.scrollX || scrollY !== s.scrollY || devicePixelRatio !== s.dpr) {
        S();
        return;
      }
      f = !0;
      const h = { ...p };
      T();
      try {
        await new Promise((w, P) => {
          const oe = setTimeout(
            () => P(
              new Error(
                "The source page stopped rendering. Keep its tab and window visible, then retry."
              )
            ),
            1e3
          );
          requestAnimationFrame(
            () => requestAnimationFrame(() => {
              clearTimeout(oe), w();
            })
          );
        });
        const y = await t.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "SELECTED",
          id: e,
          rect: h,
          viewport: {
            width: innerWidth,
            height: innerHeight,
            documentWidth: document.documentElement.scrollWidth,
            documentHeight: Math.max(document.documentElement.scrollHeight, innerHeight),
            scrollX,
            scrollY,
            dpr: devicePixelRatio,
            visualScale: visualViewport?.scale ?? 1
          }
        });
        if (!y?.ok) throw new Error(y?.error ?? "The selected area could not be captured.");
      } catch (y) {
        t.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "PAGE_CANCEL",
          id: e,
          error: y instanceof Error ? y.message : "The selected area could not be captured."
        }).catch(() => {
        });
      }
    }, O = (h) => {
      h.key === "Escape" ? (h.preventDefault(), h.stopImmediatePropagation(), C()) : ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(h.key) && h.preventDefault();
    }, x = (h, y) => Math.max(0, Math.min(y, h)), H = (h, y) => {
      u && (h = x(h, innerWidth), y = x(y, innerHeight), p = {
        x: Math.min(h, u.x),
        y: Math.min(y, u.y),
        width: Math.abs(h - u.x),
        height: Math.abs(y - u.y)
      }, l.style.display = p.width && p.height ? "block" : "none", Object.assign(l.style, {
        left: p.x + "px",
        top: p.y + "px",
        width: p.width + "px",
        height: p.height + "px"
      }), d.textContent = Math.round(p.width) + " × " + Math.round(p.height) + " px", c.style.background = p.width ? "transparent" : "#0008");
    };
    return c.addEventListener("pointerdown", (h) => {
      h.button !== 0 || f || (h.preventDefault(), c.setPointerCapture(h.pointerId), u = {
        x: x(h.clientX, innerWidth),
        y: x(h.clientY, innerHeight),
        pointerId: h.pointerId
      }, H(h.clientX, h.clientY));
    }), c.addEventListener("pointermove", (h) => {
      u?.pointerId === h.pointerId && H(h.clientX, h.clientY);
    }), c.addEventListener("pointerup", (h) => {
      !u || u.pointerId !== h.pointerId || h.button !== 0 || (H(h.clientX, h.clientY), u = null, F());
    }), c.addEventListener("pointercancel", () => {
      u = null, p = { x: 0, y: 0, width: 0, height: 0 }, l.style.display = "none", c.style.background = "#0008";
    }), window.addEventListener("keydown", O, !0), window.addEventListener("resize", S), window.addEventListener("scroll", S, !0), window.addEventListener("wheel", m, { capture: !0, passive: !1 }), window.addEventListener("touchmove", m, { capture: !0, passive: !1 }), o.__captureFlowSelection = { id: e, cleanup: T }, v = setTimeout(() => C("Selection timed out. Please try again."), 12e4), c.focus({ preventScroll: !0 }), { ok: !0 };
  } catch (t) {
    return {
      ok: !1,
      error: t instanceof Error ? t.message : "Selection is unavailable."
    };
  }
}
let Se = !1, Te = !1;
const Ae = "captureflow.lastFrameAt";
async function R() {
  return (await chrome.storage.session.get(fe))[fe] ?? null;
}
async function M(e) {
  await chrome.storage.session.set({ [fe]: e });
}
async function $(e) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#7656c9" }), await chrome.action.setBadgeText({
      text: E(e) ? e.status === "selecting" ? "SEL" : e.progress + "%" : ""
    });
  } catch {
  }
}
async function D(e) {
  const t = await chrome.tabs.get(e.sourceTabId).catch(() => {
    throw new Error("The source tab was closed during capture.");
  });
  if (!t.active || t.windowId !== e.windowId)
    throw new Error("The source tab is no longer active. Keep it selected until capture finishes.");
  if (t.url !== e.sourceUrl)
    throw new Error("The source page navigated during capture. Please try again.");
  return t;
}
async function W(e, t) {
  const r = (await chrome.scripting.executeScript({
    target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
    func: _e,
    args: [t, e.id]
  }))[0]?.result;
  if (!r) throw new Error("The page is no longer available.");
  if (!r.ok) throw new Error(r.error);
  return Me(r.value), r.value;
}
async function xe(e) {
  try {
    await W(e, { action: "restore" });
  } catch {
  }
}
async function _(e, t, o) {
  const r = await R();
  if (!r || r.id !== e.id || !E(r)) return;
  const n = { ...r, status: t, message: o, updatedAt: Date.now() };
  await M(n), await $(n), await xe(n);
}
async function ie(e) {
  const t = await R();
  if (!t || t.id !== e)
    throw new Error("This capture session has expired. Start a new capture.");
  return t;
}
function Q(e, t) {
  return e.id === chrome.runtime.id && e.url?.split("?")[0] === chrome.runtime.getURL(t);
}
async function rr(e, t) {
  if (t.id !== chrome.runtime.id) throw new Error("Untrusted capture sender.");
  if (e.type === "GET") {
    if (!Q(t, "popup.html") && !Q(t, "capture.html"))
      throw new Error("Capture state is private.");
    return R();
  }
  if (e.type === "START") {
    if (!Q(t, "popup.html"))
      throw new Error("Start capture from the CaptureFlow popup.");
    if (!["visible", "selected", "full"].includes(e.mode))
      throw new Error("Unknown capture mode.");
    if (Se) throw new Error("A capture is already starting.");
    Se = !0;
    let r = null;
    try {
      const n = await R();
      if (E(n)) {
        if (n?.coordinatorTabId !== null ? await chrome.tabs.get(n.coordinatorTabId).then(
          () => !0,
          () => !1
        ) : !1)
          throw new Error("A capture is already running. Cancel it before starting another.");
        n && await _(n, "error", "The capture tab was closed.");
      }
      const i = await $e(t);
      if (i?.id === void 0 || !i.url) throw new Error("No active webpage is available.");
      st(i.url), Re(await Ue(), "screenshot");
      const c = (await chrome.scripting.executeScript({
        target: { tabId: i.id },
        func: _e,
        args: [{ action: "inspect" }, "initial"]
      }))[0];
      if (c?.result && !c.result.ok) throw new Error(c.result.error);
      if (!c?.result?.ok || !c.documentId)
        throw new Error("This page cannot be captured. Reload the webpage and try again.");
      Me(c.result.value);
      const l = e.mode;
      r = {
        id: crypto.randomUUID(),
        mode: l,
        status: "starting",
        sourceTabId: i.id,
        windowId: i.windowId,
        documentId: c.documentId,
        sourceUrl: i.url,
        title: i.title ?? "Screenshot",
        coordinatorTabId: null,
        progress: 0,
        message: "Preparing capture…",
        updatedAt: Date.now()
      }, await M(r);
      const d = await chrome.tabs.create({
        url: chrome.runtime.getURL("capture.html") + "?id=" + r.id,
        active: !1,
        windowId: i.windowId
      });
      if (d.id === void 0) throw new Error("Could not open the screenshot workspace.");
      return r = { ...r, coordinatorTabId: d.id }, await M(r), await $(r), r;
    } catch (n) {
      throw r && await _(
        r,
        "error",
        n instanceof Error ? n.message : "Could not start capture."
      ), n;
    } finally {
      Se = !1;
    }
  }
  const o = await ie(e.id);
  if (e.type === "SELECTED" || e.type === "PAGE_CANCEL") {
    if (t.tab?.id !== o.sourceTabId || t.documentId !== o.documentId)
      throw new Error("The selection came from another page.");
    if (!E(o)) return null;
    if (e.type === "PAGE_CANCEL")
      return await _(
        o,
        e.error ? "error" : "cancelled",
        e.error ?? "Capture cancelled."
      ), null;
    if (o.status !== "selecting" || o.mode !== "selected")
      throw new Error("This session is not selecting an area.");
    lt(e.rect, e.viewport, e.viewport.width, e.viewport.height);
    const r = await W(o, { action: "inspect" });
    if (!qe(e.viewport, r))
      throw new Error("The page moved after selection. Select the area again.");
    return await M({
      ...o,
      selection: { rect: e.rect, viewport: e.viewport },
      status: "capturing",
      message: "Capturing selected area…",
      updatedAt: Date.now()
    }), null;
  }
  if (e.type === "CANCEL") {
    if (!Q(t, "popup.html") && t.tab?.id !== o.coordinatorTabId)
      throw new Error("Cannot cancel another capture.");
    return await _(o, "cancelled", "Capture cancelled."), null;
  }
  if (!Q(t, "capture.html") || t.tab?.id !== o.coordinatorTabId)
    throw new Error("This request does not belong to the active capture workspace.");
  if (e.type === "PAGE" && e.command.action === "restore")
    return await xe(o), null;
  if (!E(o)) throw new Error(o.message || "The capture has ended.");
  if (e.type === "FAIL")
    return await _(o, "error", e.error.slice(0, 500)), null;
  if (e.type === "FINISH") {
    await xe(o);
    const r = await ie(o.id);
    if (!E(r)) throw new Error(r.message);
    const n = {
      ...r,
      status: "complete",
      progress: 100,
      message: "Screenshot ready",
      updatedAt: Date.now()
    };
    return await ct("screenshot", o.id), await M(n), await $(n), await chrome.tabs.update(o.coordinatorTabId, { active: !0 }), null;
  }
  if (e.type === "PROGRESS") {
    const r = Math.max(0, Math.min(99, Math.round(e.progress)));
    if (!Number.isFinite(r)) throw new Error("Invalid capture progress.");
    const n = {
      ...o,
      status: "capturing",
      progress: r,
      message: e.message.slice(0, 200),
      updatedAt: Date.now()
    };
    return await M(n), await $(n), null;
  }
  if (e.type === "SELECT") {
    if (o.mode !== "selected" || o.status !== "starting")
      throw new Error("Selection is not available in this session.");
    await D(o), await M({
      ...o,
      status: "selecting",
      message: "Drag to select an area on the webpage.",
      updatedAt: Date.now()
    });
    const n = (await chrome.scripting.executeScript({
      target: { tabId: o.sourceTabId, documentIds: [o.documentId] },
      func: tr,
      args: [o.id]
    }))[0]?.result;
    if (!n) throw new Error("Could not open the selection overlay.");
    if (!n.ok) throw new Error(n.error);
    return await $({ ...o, status: "selecting" }), null;
  }
  if (e.type === "PAGE") {
    if (!["inspect", "prepare", "step"].includes(e.command.action))
      throw new Error("Unsupported page operation.");
    if (e.command.action === "step" && (!Number.isFinite(e.command.y) || e.command.y < 0))
      throw new Error("Invalid scroll position.");
    return await D(o), W(o, e.command);
  }
  if (e.type === "FULL_PAGE") {
    if (o.mode !== "full")
      throw new Error("Full-page capture is not available in this session.");
    await D(o);
    const r = await Zt(o);
    await D(o);
    const n = await ie(o.id);
    if (!E(n)) throw new Error(n.message);
    return r;
  }
  if (e.type === "FRAME") {
    if (Te) throw new Error("Another screenshot frame is being captured.");
    Te = !0;
    try {
      const r = Number((await chrome.storage.session.get(Ae))[Ae] ?? 0), n = Math.max(0, 650 - (Date.now() - r));
      n && await new Promise((d) => setTimeout(d, n)), await D(o);
      const i = await W(o, {
        action: o.mode === "full" ? "hideHud" : "inspect"
      });
      await chrome.storage.session.set({ [Ae]: Date.now() });
      const a = await chrome.tabs.captureVisibleTab(o.windowId, { format: "png" });
      await D(o);
      const c = await W(o, { action: "inspect" }), l = await ie(o.id);
      if (!E(l)) throw new Error(l.message);
      if (!qe(i, c) || i.documentHeight !== c.documentHeight)
        throw new Error(
          "The page moved or resized during a frame. Please retry once the page is stable."
        );
      return { dataUrl: a, viewport: c };
    } finally {
      if (o.mode === "full")
        try {
          await W(o, { action: "showHud" });
        } catch {
        }
      Te = !1;
    }
  }
  throw new Error("Unknown capture command.");
}
function or(e) {
  if (!e || typeof e != "object") throw new Error("Invalid capture message.");
  const t = e;
  if (t.type === "GET") return { type: "GET" };
  if (t.type === "START" && ["visible", "selected", "full"].includes(String(t.mode)))
    return { type: "START", mode: t.mode };
  if (typeof t.id != "string" || t.id.length > 100)
    throw new Error("Invalid capture session.");
  if (["CANCEL", "SELECT", "FRAME", "FULL_PAGE", "FINISH"].includes(String(t.type)))
    return {
      type: t.type,
      id: t.id
    };
  if (t.type === "PAGE" && t.command && typeof t.command == "object") {
    const o = t.command;
    if (["inspect", "prepare", "restore"].includes(String(o.action)))
      return {
        type: "PAGE",
        id: t.id,
        command: { action: o.action }
      };
    if (o.action === "step" && typeof o.y == "number" && Number.isFinite(o.y) && typeof o.progress == "number" && Number.isFinite(o.progress) && typeof o.hideSticky == "boolean")
      return {
        type: "PAGE",
        id: t.id,
        command: {
          action: "step",
          y: o.y,
          progress: o.progress,
          hideSticky: o.hideSticky
        }
      };
  }
  if (t.type === "PROGRESS" && typeof t.progress == "number" && typeof t.message == "string")
    return { type: "PROGRESS", id: t.id, progress: t.progress, message: t.message };
  if (t.type === "FAIL" && typeof t.error == "string")
    return { type: "FAIL", id: t.id, error: t.error };
  if (t.type === "PAGE_CANCEL" && (t.error === void 0 || typeof t.error == "string"))
    return {
      type: "PAGE_CANCEL",
      id: t.id,
      ...typeof t.error == "string" ? { error: t.error } : {}
    };
  if (t.type === "SELECTED") {
    const o = t.rect, r = t.viewport;
    return lt(o, r, r?.width, r?.height), { type: "SELECTED", id: t.id, rect: o, viewport: r };
  }
  throw new Error("Unsupported capture message.");
}
async function nr(e) {
  const t = await R();
  t && (t.coordinatorTabId === e ? (E(t) && await _(t, "cancelled", "The capture workspace was closed."), (await R())?.id === t.id && await chrome.storage.session.remove(fe)) : t.sourceTabId === e && E(t) && await _(t, "error", "The source tab was closed during capture."));
}
function Qe(e) {
  const t = Nt(Qt(e));
  if (t.mode === "tab")
    throw new Error("Firefox records windows or screens. Choose a window or screen.");
  return { ...t, audio: !1, microphone: !1 };
}
async function Y() {
  return (await chrome.storage.session.get(Ce))[Ce] ?? null;
}
async function ut(e) {
  if (e && ["starting", "recording", "paused", "stopping"].includes(e.status))
    await chrome.action.setBadgeBackgroundColor({
      color: e.status === "paused" ? "#a16207" : "#dc2626"
    }), await chrome.action.setBadgeText({
      text: e.status === "paused" ? "Ⅱ" : e.status === "recording" ? "REC" : "…"
    });
  else {
    const t = await R();
    E(t) || await chrome.action.setBadgeText({ text: "" });
  }
}
async function b(e) {
  return await chrome.storage.session.set({ [Ce]: e }), await ut(e), e;
}
function z(e, t) {
  return e.url?.split("?")[0] === chrome.runtime.getURL(t);
}
function ir(e) {
  if (e.id !== chrome.runtime.id || !["popup.html", "recording.html", "offscreen.html", "controls.html"].some(
    (t) => z(e, t)
  ))
    throw new Error("Untrusted recording request.");
}
function Xe(e, t) {
  return z(e, "recording.html") && e.tab?.id === t.controllerTabId;
}
async function ar(e) {
  const t = await Y();
  if (!t || t.id !== e)
    throw new Error("This recording session has expired. Open a new recorder.");
  return t;
}
async function dt(e) {
  if (e.controllerTabId === null) return !1;
  try {
    return (await chrome.tabs.get(e.controllerTabId)).url === chrome.runtime.getURL("recording.html?id=" + e.id);
  } catch {
    return !1;
  }
}
async function me(e, t, o = {}) {
  const r = await chrome.runtime.sendMessage({
    channel: Yt,
    target: "page:" + e.id,
    type: t,
    id: e.id,
    ...o
  });
  if (!r?.ok)
    throw new Error(
      r?.error ?? "The recording host is unavailable. Open the recorder to recover saved chunks."
    );
  return r.data;
}
async function Je(e) {
  const t = await chrome.tabs.create({
    url: chrome.runtime.getURL("recording.html?preview=" + encodeURIComponent(e)),
    active: !0
  });
  t.id !== void 0 && await Bt(e, t.id);
}
async function ge(e, t) {
  let o = await we(e.id);
  if (o) {
    o = {
      ...o,
      bytes: (await Wt(e.id, o.mimeType)).size,
      warning: o.complete ? o.warning : t + " Only previously committed chunks may be recoverable."
    };
    try {
      await jt(o);
    } catch {
    }
  }
  return b({
    ...e,
    status: o?.bytes ? "complete" : "error",
    elapsedMs: o?.durationMs ?? qt(e),
    clockStartedAt: null,
    error: o?.bytes ? "" : t,
    warning: o?.bytes ? t : e.warning
  });
}
async function pt(e, t) {
  if (ir(t), !e || typeof e != "object") throw new Error("Invalid recorder request.");
  const o = e;
  if (o.type === "GET") return Oe();
  if (o.type === "START_POPUP") return pt({ ...o, type: "PREPARE" }, t);
  if (o.type === "PREPARE") {
    if (!z(t, "popup.html"))
      throw new Error("Open the recorder from the extension popup.");
    const n = Qe(o.options), i = await Y();
    if (k(i))
      if (i?.controllerTabId !== null && i?.controllerTabId !== void 0)
        try {
          return await chrome.tabs.update(i.controllerTabId, { active: !0 }), i;
        } catch {
          if (i.status !== "setup" && await dt(i)) return i;
          await ge(i, "The recorder page was closed.");
        }
      else throw new Error("Another recording is starting.");
    if (E(await R()))
      throw new Error("Finish the screenshot capture before starting a recording.");
    const a = await $e(t);
    if (n.mode === "tab") {
      if (a?.id === void 0 || !a.url)
        throw new Error("Select a webpage before recording a tab.");
      st(a.url);
    }
    const c = crypto.randomUUID(), l = {
      id: c,
      options: n,
      owner: "page",
      controllerTabId: null,
      sourceTabId: a?.id ?? null,
      title: n.mode === "tab" ? a?.title ?? "Tab recording" : n.mode === "window" ? "Window recording" : "Screen recording",
      sourceUrl: n.mode === "tab" ? a?.url ?? "" : "",
      createdAt: Date.now(),
      status: "setup",
      elapsedMs: 0,
      clockStartedAt: null,
      hasMicrophone: !1,
      microphone: !1,
      hasAudio: !1,
      audio: !1,
      bytes: 0,
      warning: "",
      error: ""
    };
    await b(l);
    try {
      const d = await chrome.tabs.create({
        url: chrome.runtime.getURL("recording.html?id=" + c),
        active: !0
      });
      if (d.id === void 0) throw new Error("Firefox could not open the recorder.");
      return b({ ...l, controllerTabId: d.id });
    } catch (d) {
      throw await b({ ...l, status: "error", error: "Firefox could not open the recorder." }), d;
    }
  }
  if (o.type === "OPEN_PREVIEW") {
    if (typeof o.id != "string" || !await we(o.id))
      throw new Error("This saved recording is unavailable.");
    return await Je(o.id), null;
  }
  const r = await ar(o.id);
  if (o.type === "OPEN" && r.popupStart && k(r))
    return b(await Be(r));
  if (o.type === "OPEN") {
    if (r.controllerTabId !== null)
      try {
        return await chrome.tabs.update(r.controllerTabId, { active: !0 }), r;
      } catch {
      }
    const n = await chrome.tabs.create({
      url: chrome.runtime.getURL("recording.html?id=" + r.id),
      active: !0
    });
    return b({ ...r, controllerTabId: n.id ?? null });
  }
  if (o.type === "BEGIN") {
    if (!z(t, "recording.html") || t.tab?.id !== r.controllerTabId || !["setup", "error"].includes(r.status))
      throw new Error("This recording cannot start from this page or state.");
    if (E(await R())) throw new Error("Finish the screenshot before recording.");
    Re(await Ue(), "video", r.id);
    const n = Qe(o.options);
    if (n.mode !== r.options.mode)
      throw new Error("Open a new recorder to change source mode.");
    const i = await _t(), a = {
      ...r,
      options: n,
      retention: i.autoSave ? "saved" : "temporary",
      status: "starting",
      error: "",
      warning: ""
    };
    return await b(a), a;
  }
  if (o.type === "UPDATE") {
    if (!Xe(t, r))
      throw new Error("Only the current recording host may publish state.");
    if (!k(r)) return r;
    const n = o.snapshot;
    if (!n || !["starting", "recording", "paused", "stopping", "complete", "error"].includes(
      String(n.status)
    ) || !Number.isFinite(n.elapsedMs) || !Number.isFinite(n.bytes) || n.elapsedMs < 0 || n.bytes < 0 || !(n.clockStartedAt === null || Number.isFinite(n.clockStartedAt)) || !["audio", "hasAudio", "microphone", "hasMicrophone"].every(
      (a) => typeof n[a] == "boolean"
    ) || typeof n.warning != "string")
      throw new Error("Invalid recording state.");
    if (n.status === "recording" && r.status === "starting")
      try {
        await ct("video", r.id);
      } catch (a) {
        throw await me(r, "STOP", { reason: "Monthly usage could not be saved." }).catch(
          () => {
          }
        ), a;
      }
    let i = await b({
      ...r,
      status: n.status === "complete" ? "stopping" : n.status,
      elapsedMs: n.elapsedMs,
      clockStartedAt: n.clockStartedAt,
      bytes: n.bytes,
      microphone: !1,
      hasMicrophone: !1,
      audio: n.audio,
      hasAudio: n.hasAudio,
      warning: n.warning,
      error: n.status === "error" ? n.warning : ""
    });
    if (r.popupStart && n.status === "recording" && !r.controlsOpened)
      try {
        i = await b(await Be(i, !0));
      } catch (a) {
        i = await b({
          ...i,
          controlsOpened: !0,
          controlsError: a instanceof Error ? a.message : "Open recording controls from the extension popup."
        });
      }
    return n.status === "error" && await Ee(r), i;
  }
  if (o.type === "COMPLETE") {
    if (!Xe(t, r)) throw new Error("Only the current host may finish recording.");
    const n = await we(r.id);
    if (!n) throw new Error("The recording could not be saved locally.");
    const i = await b({
      ...r,
      status: n.bytes ? "complete" : "error",
      elapsedMs: n.durationMs,
      clockStartedAt: null,
      bytes: n.bytes,
      warning: n.warning,
      error: n.bytes ? "" : "No video data was saved."
    });
    try {
      await Ee(r), n.bytes && await Je(r.id);
    } finally {
      ce();
    }
    return i;
  }
  if (o.type === "FAIL") {
    if (!z(t, "recording.html") || t.tab?.id !== r.controllerTabId)
      throw new Error("Untrusted recording failure.");
    if (!["setup", "starting", "error"].includes(r.status))
      throw new Error("The recording is already running.");
    return b({
      ...r,
      status: "error",
      clockStartedAt: null,
      error: typeof o.error == "string" ? o.error : "Recording start failed."
    });
  }
  if (o.type === "CANCEL_SETUP") {
    if (!["setup", "error"].includes(r.status))
      throw new Error("Stop the active recording first.");
    return b({ ...r, status: "cancelled", error: "" });
  }
  if (["PIN_CONTROLS", "UNPIN_CONTROLS", "CLOSE_CONTROLS"].includes(String(o.type))) {
    if (!z(t, "controls.html") || t.tab?.id !== r.controlsTabId || r.controlsWindowId == null)
      throw new Error("Only this recording controls window may change its visibility.");
    return o.type === "PIN_CONTROLS" ? await chrome.windows.update(r.controlsWindowId, { state: "minimized" }) : o.type === "UNPIN_CONTROLS" ? await chrome.windows.update(r.controlsWindowId, {
      state: "normal",
      focused: !0,
      width: 280,
      height: 106
    }) : await Ee(r), null;
  }
  if (o.type === "CONTROL") {
    if (!["PAUSE", "RESUME", "STOP", "AUDIO"].includes(String(o.command)))
      throw new Error("Unknown recording control.");
    if (!k(r) || r.status === "setup")
      throw new Error("No active recording is available.");
    if (o.command === "AUDIO" && typeof o.enabled != "boolean")
      throw new Error("Invalid audio toggle.");
    return me(r, String(o.command), { enabled: o.enabled === !0 });
  }
  throw new Error("Unknown recording request.");
}
async function cr(e) {
  const t = await Y();
  if (!(!t || !k(t))) {
    if (t.controlsTabId === e) {
      await b({ ...t, controlsWindowId: null, controlsTabId: null });
      return;
    }
    if (t.sourceTabId === e && t.options.mode === "tab" && t.status !== "setup")
      try {
        await me(t, "STOP", { reason: "The source tab closed." });
      } catch {
        await ge(t, "The source tab closed.");
      }
    else t.controllerTabId === e && await ge(t, "The recorder tab closed.");
  }
}
async function Oe() {
  let e = await Y();
  if (e && k(e) && e.status !== "setup") {
    let t = !await dt(e);
    if (!t && ["recording", "paused", "stopping"].includes(e.status))
      try {
        await me(e, "PING");
      } catch {
        t = !0;
      }
    t && (e = await ge(e, "The recording host closed or was interrupted."));
  }
  return e;
}
async function sr() {
  const e = chrome.runtime.getURL("");
  return (await chrome.tabs.query({})).filter((t) => t.url?.startsWith(e)).map((t) => ({ documentUrl: t.url }));
}
async function lr(e = null) {
  return I(["screenshots", "recordings"], "readonly", (t, o) => {
    const r = t.objectStore("screenshots").getAll(), n = t.objectStore("recordings").getAll();
    let i = 0;
    const a = () => {
      if (++i !== 2) return;
      const c = [
        ...r.result,
        ...n.result.filter((l) => l.id !== e && l.bytes > 0 && l.retention !== "temporary").map((l) => ({
          id: l.id,
          kind: "recording",
          title: l.title,
          sourceUrl: l.sourceUrl ?? "",
          createdAt: l.createdAt,
          updatedAt: l.createdAt,
          bytes: l.bytes,
          durationMs: l.durationMs,
          complete: l.complete,
          warning: l.warning
        }))
      ];
      o(c.sort((l, d) => d.createdAt - l.createdAt || l.id.localeCompare(d.id)));
    };
    r.onsuccess = a, n.onsuccess = a;
  });
}
async function ur(e, t, o = null) {
  if (e === "recording" && t === o)
    throw new Error("Stop the active recording before deleting it.");
  await I(["screenshots", "recordings", "chunks", "assets"], "readwrite", (r) => {
    r.objectStore(e === "screenshot" ? "screenshots" : "recordings").delete(t), e === "recording" && Fe(r, t), he(r, t);
  });
}
async function dr(e = null) {
  return I(
    ["screenshots", "recordings", "chunks", "assets"],
    "readwrite",
    (t, o) => {
      let r = 0, n = 2;
      const i = t.objectStore("screenshots").openCursor(), a = t.objectStore("recordings").openCursor();
      i.onsuccess = () => {
        const c = i.result;
        if (!c) {
          --n || o(r);
          return;
        }
        he(t, String(c.primaryKey)), c.delete(), r++, c.continue();
      }, a.onsuccess = () => {
        const c = a.result;
        if (!c) {
          --n || o(r);
          return;
        }
        const l = c.value;
        l.id !== e && l.retention !== "temporary" && (Fe(t, l.id), he(t, l.id), c.delete(), r++), c.continue();
      };
    }
  );
}
async function pr(e = null) {
  return I(
    ["screenshots", "recordings", "chunks", "assets"],
    "readwrite",
    (t, o) => {
      const r = t.objectStore("screenshots").getAllKeys(), n = t.objectStore("recordings").getAllKeys();
      let i = 2;
      const a = () => {
        if (--i) return;
        const c = new Set([...r.result, ...n.result].map(String));
        e && c.add(e);
        let l = 0, d = 2;
        for (const s of ["chunks", "assets"]) {
          const u = t.objectStore(s).openKeyCursor();
          u.onsuccess = () => {
            const p = u.result;
            if (!p) {
              --d || o(l);
              return;
            }
            const f = p.primaryKey;
            c.has(f[0]) || (t.objectStore(s).delete(p.primaryKey), l++), p.continue();
          };
        }
      };
      r.onsuccess = a, n.onsuccess = a;
    }
  );
}
async function re(e = !1, t) {
  const o = t === void 0 ? await Oe() : null, r = t === void 0 ? k(o) ? o.id : null : t, n = new Set(r ? [r] : []);
  if (!e && (await Kt()).some((i) => i.retention === "temporary")) {
    for (const i of await sr())
      if (i.documentUrl)
        try {
          const a = new URL(i.documentUrl);
          if (a.protocol !== new URL(chrome.runtime.getURL("")).protocol || a.host !== new URL(chrome.runtime.getURL("")).host || a.pathname !== "/recording.html")
            continue;
          const c = a.searchParams.get("preview");
          c && n.add(c);
        } catch {
        }
  }
  return await zt(n), await pr(r ?? null), r ?? null;
}
async function hr(e, t) {
  if (t.id !== chrome.runtime.id || !["popup.html", "capture.html", "recording.html", "history.html"].some(
    (i) => t.url?.split("?")[0] === chrome.runtime.getURL(i)
  ))
    throw new Error("History is private to CaptureFlow pages.");
  if (!e || typeof e != "object") throw new Error("Invalid history request.");
  const o = e, r = await Oe(), n = k(r) ? r.id : null;
  if (o.type === "LIST")
    return await re(!1, n), { items: await lr(n), activeRecordingId: n };
  if (o.type === "DELETE") {
    if (!["screenshot", "recording"].includes(String(o.kind)) || typeof o.id != "string" || !o.id)
      throw new Error("Invalid history item.");
    await ur(o.kind, o.id, n);
  } else if (o.type === "CLEAR") {
    const i = await dr(n);
    return await re(!1, n), ce(), i;
  } else if (o.type === "KEEP_RECORDING") {
    if (typeof o.id != "string" || o.id === n)
      throw new Error("Finish recording before keeping it in history.");
    if (!(await we(o.id))?.bytes) throw new Error("This recording is unavailable.");
    const a = await Gt(o.id);
    return ce(), a;
  } else throw new Error("Unknown history request.");
  return ce(), null;
}
const ht = "captureflow/v1";
function wr(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.channel === ht && t.type === "GET_APP_INFO";
}
function fr(e, t, o, r) {
  return t !== o ? { ok: !1, error: "Untrusted message sender." } : wr(e) ? {
    ok: !0,
    data: {
      version: r,
      phase: 6,
      capabilities: [
        "preferences",
        "themes",
        "navigation",
        "screenshots",
        "annotations",
        "recording",
        "history"
      ]
    }
  } : { ok: !1, error: "Unsupported CaptureFlow message." };
}
function X(e) {
  const t = e instanceof Error ? e.message : "An unexpected error occurred.";
  return /quota|QUOTA_BYTES/i.test(t) ? "Local storage is full. Free some space and try again." : /receiving end|connection|message port|timed out/i.test(t) ? "Cannot reach CaptureFlow. Reload the extension in your browser’s extension manager and try again." : t;
}
function He() {
  let e = Promise.resolve();
  return (t) => {
    const o = e.then(t);
    return e = o.then(
      () => {
      },
      () => {
      }
    ), o;
  };
}
const q = He(), wt = q, Pe = He(), mr = He();
chrome.runtime.onMessage.addListener((e, t, o) => e && typeof e == "object" && "channel" in e && e.channel === yt ? !("type" in e) || e.type !== "OPEN" ? (o({ ok: !1, error: "Unknown window request." }), !1) : (mr(() => mt(t)).then(
  () => o({ ok: !0 }),
  (r) => o({ ok: !1, error: X(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === It ? (("type" in e && e.type === "STATUS" ? We(e, t) : Pe(() => We(e, t))).then(
  (n) => o({ ok: !0, data: n }),
  (n) => o({ ok: !1, error: X(n) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Lt ? (Pe(() => Ut(e, t)).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: X(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Rt ? (q(async () => (await A(), hr(e, t))).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: Ft(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Vt ? (wt(async () => (await A(), pt(e, t))).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: X(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === er ? (q(async () => {
  await A();
  const r = or(e);
  if (r.type === "START" && k(await Y()))
    throw new Error("Finish or cancel the recorder before capturing screenshots.");
  const n = await rr(r, t), i = await Y();
  return k(i) && await ut(i), n;
}).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: X(r) })
), !0) : (!e || typeof e != "object" || !("channel" in e) || e.channel !== ht || o(
  fr(e, t.id, chrome.runtime.id, chrome.runtime.getManifest().version)
), !1));
chrome.tabs.onRemoved.addListener((e) => {
  wt(async () => {
    await cr(e), await re();
  }).catch(console.error), q(() => nr(e)).catch(console.error);
});
chrome.runtime.onStartup?.addListener(() => {
  q(() => re(!0)).catch(console.error);
});
chrome.runtime.onInstalled?.addListener(() => {
  chrome.storage.local.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" }), q(() => re(!0)).catch(console.error);
});
chrome.windows?.onFocusChanged?.addListener((e) => {
  gt(e).catch(() => {
  });
});
V() && chrome.permissions.onRemoved.addListener((e) => {
  ((e.data_collection ?? []).some((o) => Ze.includes(o)) || e.origins?.some((o) => o.startsWith("https://captureflow-billing."))) && Pe(() => G(!1)).catch(() => {
  });
});
